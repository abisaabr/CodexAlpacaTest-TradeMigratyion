# Scheduler Setup Note

Target date: Monday 2026-04-06
Recommended launch time: `09:20 ET`

Windows Task Scheduler suggestion:
- Program: `powershell.exe`
- Arguments: `-ExecutionPolicy Bypass -File "C:\Users\rabisaab\Downloads\alpaca_paper_handoff_20260406\run_qqq_pair_paper.ps1"`
- Start in: `C:\Users\rabisaab\Downloads\alpaca_paper_handoff_20260406`

Do not schedule RS, CSM, or DSE for Monday. The approved Monday paper set is the QQQ pair only.
