# Monday 2026-04-06 Paper Handoff

Approved strategy: `qqq_led_tqqq_sqqq_pair_opening_range_intraday_system` only.

This bundle contains:
- `paper_shared_config.yaml`
- `run_qqq_pair_paper.ps1`
- `.env.template`
- `scheduler_setup_note.md`

Important limitation:
- The approval came from the exact bar-only adverse-baseline backtest on `2026-02-02` through `2026-03-31`.
- The live paper runtime uses the repo's operational engine, so sizing and kill-switch behavior are intentionally stricter than the bar-only research harness.
- `down_streak_exhaustion`, `relative_strength_vs_benchmark::rs_top3_native`, and `cross_sectional_momentum::csm_native` are not approved for Monday paper trading.

Launch steps:
1. Copy or clone `nasdaq-etf-intraday-alpaca` onto the other machine.
2. Put this handoff folder next to that repo, or pass the repo path explicitly to the runner script.
3. Fill the environment variables from `.env.template`.
4. Run `run_qqq_pair_paper.ps1` before the open on Monday 2026-04-06.
5. Review logs and reports after the session before changing anything.
