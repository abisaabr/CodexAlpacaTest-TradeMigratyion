param(
  [string]$RepoRoot = "$PSScriptRoot\..\nasdaq-etf-intraday-alpaca",
  [switch]$Shadow
)

$RepoRoot = (Resolve-Path -LiteralPath $RepoRoot).Path
$ConfigPath = (Resolve-Path -LiteralPath (Join-Path $PSScriptRoot 'paper_shared_config.yaml')).Path

if (-not $env:APCA_API_KEY_ID) { throw 'Missing APCA_API_KEY_ID.' }
if (-not $env:APCA_API_SECRET_KEY) { throw 'Missing APCA_API_SECRET_KEY.' }
if (-not $env:APCA_API_BASE_URL) { $env:APCA_API_BASE_URL = 'https://paper-api.alpaca.markets' }
$env:ALLOW_LIVE_TRADING = 'false'
$env:PYTHONPATH = if ($env:PYTHONPATH) { "$RepoRoot\src;$env:PYTHONPATH" } else { "$RepoRoot\src" }

Push-Location $RepoRoot
try {
  if ($Shadow) {
    python -m app.paper --config $ConfigPath --shadow
  } else {
    python -m app.paper --config $ConfigPath
  }
}
finally {
  Pop-Location
}
