# Runtime Migration Bundle

Use this bundle on the destination machine after cloning the repo.

1. Check out the same branch/commit as the source machine.
2. Run the restore script against this bundle.
3. Override the machine label on the destination machine.
4. Run the standby failover check.
5. Start the trader only after the failover check passes.

Suggested commands:

```powershell
python scripts\restore_multi_ticker_migration_bundle.py "C:\Users\rabisaab\Downloads\migration_repo_staging\public_runtime_migration_20260417" --target-repo "C:\Users\rabisaab\Downloads\codexalpaca_repo" --machine-label <new-machine-label>
python scripts\run_multi_ticker_standby_failover_check.py
```

Notes:
- Clone the same repo branch on the destination machine before restoring this bundle.
- Run the standby failover check before starting the trader.
- Do not let both machines actively trade unless they share the same ownership lease path.
- This bundle includes live runtime state for trade date 2026-04-17. Restore it before starting the runner.
- Configured shared lease path: C:\Users\rabisaab\OneDrive\CodexAlpaca\leases\multi_ticker_portfolio.json
- Source machine label was 'desktop-rabisaab'. Override it on the destination machine so the labels stay distinct.
- Checkout the same code before restoring: branch=codex/qqq-paper-portfolio commit=3f82228c68ada955a97ed09418975f34a99ba9ed.